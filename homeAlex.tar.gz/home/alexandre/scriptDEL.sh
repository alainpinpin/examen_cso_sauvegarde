#!/bin/bash

while :
do
	#cmon=$(cat /sys/class/gpio/gpio233/value)
	if [ $(cat /sys/class/gpio/gpio233/value) -eq 1 ];
		then
			echo 1 > /sys/class/gpio/gpio71/value
		else
			echo 0 > /sys/class/gpio/gpio71/value
	fi
done
